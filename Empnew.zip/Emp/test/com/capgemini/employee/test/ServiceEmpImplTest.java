package com.capgemini.employee.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.ServiceEmpImpl;

public class ServiceEmpImplTest {
	
	private EmployeeBean employeeBean;
	
	@Before
	public void setUp() throws Exception {
		employeeBean = new EmployeeBean("Gaurav",95000,20,"Banker");
	}

	@After
	public void tearDown() throws Exception {
		employeeBean=null;
	}

	@Test
	public final void testUpdateSal() {
		ServiceEmpImpl serviceEmp = new ServiceEmpImpl();
		try {
			assertTrue(serviceEmp.updateSal(4,35000));
		}catch(EmployeeException e){
			e.printStackTrace();
		}
	}

	@Test
	public final void testDeleteEmp() {
		ServiceEmpImpl serviceEmp = new ServiceEmpImpl();
		try {
			assertTrue(serviceEmp.deleteEmp(6));
		}catch(EmployeeException e){
			e.printStackTrace();
		}
	}

	@Ignore
	public final void testSearch() {
		fail("Not yet implemented");
	}

	@Test
	public final void testInsertEmp() {
		ServiceEmpImpl serviceEmp = new ServiceEmpImpl();
		try {
			assertTrue(serviceEmp.insertEmp(employeeBean));
		}catch(EmployeeException e){
			e.printStackTrace();
		}
	}

}
