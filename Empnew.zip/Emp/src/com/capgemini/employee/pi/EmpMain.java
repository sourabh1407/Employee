package com.capgemini.employee.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.ServiceEmpImpl;

public class EmpMain {
	private static Logger logger=Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");

		boolean isInProcess = true;
		boolean isValid = false;
		
		byte choice = 0;
		
		String ename = null;
		String designation = null;
		int salary = 0;
		int dept = 0;
		int empid=0;
		
		ServiceEmpImpl serviceEmp = new ServiceEmpImpl();
		
		EmployeeBean employeeBean = null;
		
		List<EmployeeBean>empList = null;
		
		Scanner scan = new Scanner(System.in);
		
		while (isInProcess){
			System.out.println("1. Insert Employee");
			System.out.println("2. View all Employee");
			System.out.println("3. Delete employee details.");
			System.out.println("4. Search employee");
			System.out.println("5. Update employee salary");
			System.out.println("0. Exit");
			
			choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1:
				isValid = false;

				while(!isValid){

					try{
						System.out.println("Enter employee name: ");
						ename= scan.nextLine();
						
						isValid = serviceEmp.isValidEName(ename);
						
					}catch(EmployeeException mpe){
						logger.error("Invalid name: " +ename);
						System.err.println("Invalid name: " +ename);
						isValid = false;
					}
				}
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter salary: ");
						salary= Integer.parseInt(scan.nextLine());
						
						isValid = serviceEmp.isValidSalary(salary);
						
					}catch(EmployeeException mpe){
						logger.error("Invalid salary: " +salary);
						System.err.println("Invalid salary: " +salary);
						isValid = false;
					}
				}
				
				System.out.println("Enter employee dept no: ");
				dept= Integer.parseInt(scan.nextLine());		
				//scan.nextLine();
				
				System.out.println("Enter employee designation: ");
				designation= scan.nextLine();
				
				employeeBean = new EmployeeBean(ename,salary,dept,designation);
				try{
					boolean isInserted =serviceEmp.insertEmp(employeeBean);
					if (isInserted) {
						System.out.println("Employee inserted successfully");
					} else {
						System.out.println("No records insserted");
					}
				}catch(EmployeeException e){
					logger.error(e.getMessage());
				}
				
				break;
			
			case 2:
				try{
				empList = serviceEmp.viewAll();
					for (EmployeeBean EmployeeBean : empList){
						System.out.println(EmployeeBean);
					}
					System.out.println("====================================================================");
				}catch(EmployeeException e){
					logger.error(e.getMessage());
				}
				break;
				
			case 3:
				isValid = false;
				System.out.println("Enter employee id: ");
				empid= Integer.parseInt(scan.nextLine());				
				
				try{
					boolean isDeleted = serviceEmp.deleteEmp(empid);
					if(isDeleted){
						System.out.println("Employee record deleted successfully");
					}
				}catch(EmployeeException e){
					logger.error(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter employee id: ");
				empid= Integer.parseInt(scan.nextLine());
				
				try{
				empList = serviceEmp.search(empid);
				if (empList!=null) {
					for (EmployeeBean EmployeeBean : empList){
						System.out.println(EmployeeBean);
					}
				} else {
					System.out.println("No employee found");
				}	
				
					System.out.println("====================================================================");
				}catch(EmployeeException e){
					System.err.print("No records found");
					logger.error(e.getMessage());
				}
				
				break;
			case 5:
				//int salary = 0;
				//int empid = 0;
				boolean isUpdated=false;
				System.out.println("Enter empid ");
				empid = Integer.parseInt(scan.nextLine());
				System.out.println("Enter salary");
				salary = Integer.parseInt(scan.nextLine());

				try{
					isUpdated = serviceEmp.updateSal(empid,salary);
/*					if (isUpdated) {
						for(EmployeeBean EmployeeBean : empList){
							System.out.println(EmployeeBean);
						}	
					} else {
						System.out.println("No records updated");
					}*/
					
					if (isUpdated) {
						System.out.println("Salary updated succeessfully");
					} else {
						System.out.println("No records updated");
					}
					
					System.out.println("===================================================================");
				}catch(EmployeeException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 0:
				isInProcess = false;
				System.out.println("Exited successfully");
				break;
			default:
				System.out.println("Invalid Input");
				logger.error("Invalid Input: " +choice);
				System.err.println("Invalid Input: " +choice);
			}
			
		}
		scan.close();
	}

}
