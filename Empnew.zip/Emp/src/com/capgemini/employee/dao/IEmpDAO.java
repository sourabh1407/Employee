package com.capgemini.employee.dao;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;


public interface IEmpDAO {

	public boolean updateSal(final int empid,final int salary)
	throws EmployeeException;
	
	public List<EmployeeBean> viewAll() throws EmployeeException;
	
	public boolean deleteEmp(final int empid)
	throws EmployeeException;
	
	public List<EmployeeBean> search(final int empid)
	throws EmployeeException;
	
	public boolean insertEmp	(final EmployeeBean employeeBean)
	throws EmployeeException;
	
	
}
