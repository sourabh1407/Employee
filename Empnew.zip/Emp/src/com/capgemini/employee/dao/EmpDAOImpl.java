package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.util.DBConnection;


public class EmpDAOImpl implements IEmpDAO {

	@Override
	public boolean updateSal(int empid, int salary) throws EmployeeException {
		int records =0;
		boolean isUpdated=false;
		
		try(Connection connEmp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=
						connEmp.prepareStatement(QueryMapperEmployee.UPDATE_EMP);){
									
			preparedStatement.setInt(1, salary);
			preparedStatement.setInt(2, empid);
			
			records = preparedStatement.executeUpdate();
			
			if (records>0) {
				isUpdated = true;
			}
			
		}catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return isUpdated;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException {
		List<EmployeeBean> empList = new ArrayList<EmployeeBean>();
		try(Connection connemp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=connemp.prepareStatement(QueryMapperEmployee.VIEWALL_EMP);
				ResultSet rsemps = preparedStatement.executeQuery();			
				){
				while(rsemps.next()){
				EmployeeBean emp = new EmployeeBean();
				emp.setEmpid(rsemps.getInt("empid"));
				emp.setEname(rsemps.getString("ename"));
				emp.setSalary(rsemps.getInt("salary"));
				emp.setDept(rsemps.getInt("dept"));
				emp.setDesignation(rsemps.getString("designation"));
				
				empList.add(emp);
			}
				if(empList.size()==0){
					throw new EmployeeException("No records found.");
				}
		}catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return empList;
	}

	@Override
	public boolean deleteEmp(int empid) throws EmployeeException {
		int records =0;
		boolean isUpdated=false;
		
		try(Connection connEmp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=
						connEmp.prepareStatement(QueryMapperEmployee.DELETE_EMP);){
									
			
			preparedStatement.setInt(1, empid);
			
			records = preparedStatement.executeUpdate();
			
			if (records>0) {
				isUpdated = true;
			}
			
		}catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return isUpdated;
	}

	@Override
	public List<EmployeeBean> search(int empid) throws EmployeeException {
		List<EmployeeBean> empList = new ArrayList<EmployeeBean>();
		try(Connection connemp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=connemp.prepareStatement(QueryMapperEmployee.SEARCH_EMP);
							
				){
				preparedStatement.setInt(1, empid);
			    ResultSet rsemps = preparedStatement.executeQuery();
				
			    while(rsemps.next()){
				EmployeeBean emp = new EmployeeBean();
				emp.setEmpid(rsemps.getInt("empid"));
				emp.setEname(rsemps.getString("ename"));
				emp.setSalary(rsemps.getInt("salary"));
				emp.setDept(rsemps.getInt("dept"));
				emp.setDesignation(rsemps.getString("designation"));
				
				empList.add(emp);
			}
				if(empList.size()==0){
					throw new EmployeeException("No records found.");
				}
		}catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return empList;
	}

	@Override
	public boolean insertEmp(EmployeeBean employeeBean)
			throws EmployeeException {
		int records =0;
		boolean isInserted=false;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperEmployee.INSERT_EMP);){
			
			
			preparedStatement.setString(1, employeeBean.getEname());
			preparedStatement.setInt(2, employeeBean.getSalary());
			preparedStatement.setInt(3, employeeBean.getDept());
			preparedStatement.setString(4, employeeBean.getDesignation());
			
			records = preparedStatement.executeUpdate();
			
			if (records>0) {
				isInserted = true;
			}
			
		}catch(SQLException sqlEx)
		{
			throw new EmployeeException(sqlEx.getMessage());
		}
		return isInserted;
	}

}
