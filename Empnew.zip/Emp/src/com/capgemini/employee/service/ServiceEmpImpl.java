package com.capgemini.employee.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.dao.EmpDAOImpl;
import com.capgemini.employee.dao.IEmpDAO;
import com.capgemini.employee.exception.EmployeeException;

//private static Logger logger=Logger.getRootLogger();
//public static Logger logger= Logger.getRootLogger();

public class ServiceEmpImpl implements IServiceEmp {
	//PropertyConfigurator.configure("resources/log4j.properties");
	IEmpDAO empDAO = new EmpDAOImpl();
	
	@Override
	public boolean updateSal(int empid, int salary) throws EmployeeException {
		IEmpDAO empDAO = new EmpDAOImpl();

		boolean isUpdated = empDAO.updateSal(empid,salary);
		return (isUpdated);
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException {
		List<EmployeeBean> empList = empDAO.viewAll();
		return empList;
	}

	@Override
	public boolean deleteEmp(int empid) throws EmployeeException {
		IEmpDAO empDAO = new EmpDAOImpl();

		boolean isDeleted = empDAO.deleteEmp(empid);
		return (isDeleted);
	}

	@Override
	public List<EmployeeBean> search(int empid) throws EmployeeException {
		List<EmployeeBean> empList = empDAO.search(empid);
		return empList;
	}

	@Override
	public boolean insertEmp(EmployeeBean employeeBean)
			throws EmployeeException {
		boolean isItInserted = false;

		
		IEmpDAO empDAO = new EmpDAOImpl();
		
		isItInserted=empDAO.insertEmp(employeeBean);
		return isItInserted; 
		
	
	}
	
	public boolean isValidEName(String ename) throws EmployeeException{
		boolean isValid = false;
		
		String pattern ="[A-Z]{1}[A-Za-z]{1,19}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(ename);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new EmployeeException("Invalid name");
			
		}
		
		return isValid;
	}
	public boolean isValidSalary(int salary)throws EmployeeException{
		boolean isValid = true;
		
		if(salary<0){
			throw new EmployeeException("Salary should be positive number");
			//logger.error("Invalid salary");
		}
		return isValid;
	}
	

}
